
import turtle
import time
import random

delay = 0.1
score = 0
high_score = 0

# Creating a window screen
Screen = turtle.Screen()
Screen.title("Snake Game")
Screen.bgcolor("black")
Screen.setup(width=600, height=600)
#for no glitshing
Screen.tracer(0)

# head of the snake
Snake_Head = turtle.Turtle()
Snake_Head.shape("square")
Snake_Head.color("white")
Snake_Head.penup()
Snake_Head.goto(0,0)
Snake_Head.direction = "Stop"

# food in the game
food = turtle.Turtle()
colors = random.choice(['red', 'green', 'blue','yellow'])
shapes = random.choice(['square', 'triangle', 'circle'])
food.speed(0)
food.shape(shapes)
food.color(colors)
food.penup()
food.goto(0, 100)

pen = turtle.Turtle()
pen.speed(0)
pen.shape("square")
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(0, 250)
pen.write("Score : 0 High Score : 0", align="center",font=("candara", 24, "bold"))

# assigning key directions
def GoUp():
	if Snake_Head.direction != "down":
    		Snake_Head.direction = "up"

def GoDown():
	if Snake_Head.direction != "up":
		Snake_Head.direction = "down"

def GoLeft():
	if Snake_Head.direction != "right":
		Snake_Head.direction = "left"

def GoRight():
	if Snake_Head.direction != "left":
		Snake_Head.direction = "right"

def Move():
	if Snake_Head.direction == "up":
		y = Snake_Head.ycor()
		Snake_Head.sety(y+20)
  
	if Snake_Head.direction == "down":
		y = Snake_Head.ycor()
		Snake_Head.sety(y-20)
  
	if Snake_Head.direction == "left":
		x = Snake_Head.xcor()
		Snake_Head.setx(x-20)
  
	if Snake_Head.direction == "right":
		x = Snake_Head.xcor()
		Snake_Head.setx(x+20)

#keys sensing
Screen.listen()
Screen.onkeypress(GoUp, "w")
Screen.onkeypress(GoDown, "s")
Screen.onkeypress(GoLeft, "a")
Screen.onkeypress(GoRight, "d")

Snake_Body = []

# Playing time
while True:
	Screen.update()
 
   #check collision with border area
	if Snake_Head.xcor() > 290 or Snake_Head.xcor() < -290 or Snake_Head.ycor() > 290 or Snake_Head.ycor() < -290:
		time.sleep(1)
		Snake_Head.goto(0, 0)
		Snake_Head.direction = "Stop"
    
    #hide the Snake body because it's over
		for cube in Snake_Body:
			cube.goto(1000, 1000)
   
    #clear the Snake Body
		Snake_Body.clear()
  
    #reset score
		score = 0
  
    #reset delay
		delay = 0.1
  
    #update screen
		pen.clear()
		pen.write("Score : {} High Score : {} ".format(score, high_score), align="center", font=("candara", 24, "bold"))
  
	if Snake_Head.distance(food) < 20:
		x = random.randint(-270, 270)
		y = random.randint(-270, 270)
		colors = random.choice(['red', 'green', 'blue','yellow'])
		shapes = random.choice(['square', 'triangle', 'circle'])
		food.speed(0)
		food.shape(shapes)
		food.color(colors)
		food.goto(x, y)

		# Adding cube for the body
		new_cube = turtle.Turtle()
		new_cube.speed(0)
		new_cube.shape("square")
		new_cube.color("orange") # tail colour
		new_cube.penup()
		Snake_Body.append(new_cube)
  
	# Shorten the delay
		delay -= 0.001
  
  # Increase the score
		score += 1
  
		if score > high_score:
			high_score = score
   
		pen.clear()
		pen.write("Score : {} High Score : {} ".format(score, high_score), align="center", font=("candara", 24, "bold"))
  
	# Move the body pices in reverse order
	# Here I set the for loop to start from the last body piece , till reaching zero , and decreaminting by 1
    # to be able to set the body pices in reverse order perfictly
	for index in range(len(Snake_Body)-1, 0, -1):
		x = Snake_Body[index-1].xcor()
		y = Snake_Body[index-1].ycor()
		Snake_Body[index].goto(x, y)
  
   # Move the first pice to head
	if len(Snake_Body) > 0:
		x = Snake_Head.xcor()
		y = Snake_Head.ycor()
		Snake_Body[0].goto(x, y)
  
	Move()
 
	time.sleep(delay)

Screen.mainloop()

turtle.done()